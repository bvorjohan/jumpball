// this file runs on page load, and can interact with the DOM


// test to be sure is working an filter domains correctly
alert("Hello")
console.log(chrome)


// TODO: only begin when meeting starts (not on page load)
// TODO: figure out muting people
