// I run in the background, can persist for the duration of the browser session,
// and am useful for storing state, listening for browser events, etc.
// this is where you would store, update, load, etc. your personal settings.
console.log("background.js loaded")
